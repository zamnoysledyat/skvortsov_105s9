<?php
session_start();

// Подключаем файл с настройками подключения к БД
include 'db.php';

// Получаем события из таблицы ленты активности
$stmt = $pdo->prepare('SELECT * FROM activity_feed ORDER BY created_at DESC');
$stmt->execute();
$activities = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Лента активности</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .activity-item {
            border-left: 4px solid #007bff;
            padding-left: 1rem;
            margin-bottom: 1.5rem;
        }
        .activity-item.completed { border-left-color: #28a745; }
        .activity-item.overdue { border-left-color: #dc3545; }
        .activity-item.task-created { border-left-color: #17a2b8; }
        .activity-item.task-assigned { border-left-color: #ffc107; }
        .activity-time {
            font-size: 0.9rem;
            color: #6c757d;
        }
        .activity-description {
            font-size: 1rem;
        }
        .activity-user {
            font-weight: bold;
            color: #007bff;
        }
    </style>
</head>
<body>
<?php include 'header.inc'; ?>
    <div class="container my-4">
        <h2>Лента активности</h2>
        <div class="mt-3">
            <?php
            // Перебираем все события из ленты активности
            foreach ($activities as $activity) {
                // Получаем имя пользователя, который выполнил активность
                $stmt = $pdo->prepare('SELECT full_name FROM users WHERE id = :user_id');
                $stmt->execute(['user_id' => $activity['user_id']]);
                $user_name = $stmt->fetch(PDO::FETCH_ASSOC)['full_name'];

                // Получаем информацию о задаче
                $stmt = $pdo->prepare('SELECT id, task_name, task_deadline, user_id, status FROM tasks WHERE id = :task_id');
                $stmt->execute(['task_id' => $activity['task_id']]);
                $task = $stmt->fetch(PDO::FETCH_ASSOC);

                if (!$task) {
                    // Если задача не найдена, пропускаем этот цикл
                    continue;
                }

                // Для отчетов
                if ($activity['report_id']) {
                    $stmt = $pdo->prepare('SELECT report_title, report_description FROM reports WHERE id = :report_id');
                    $stmt->execute(['report_id' => $activity['report_id']]);
                    $report = $stmt->fetch(PDO::FETCH_ASSOC);
                    $report_name = $report['report_title'];
                    $report_description = $report['report_description'];
                }

                // Тип активности и описание
                switch ($activity['activity_type']) {
                    case 'task_created':
                        $activity_class = 'task-created';
                        $description = "Создал задачу <strong>\"{$task['task_name']}\"</strong> с дедлайном <strong>{$task['task_deadline']}</strong>";
                        break;
                    case 'task_assigned':
                        $activity_class = 'task-assigned';

                        // Получаем ID пользователя, которому назначена задача из таблицы tasks
                        $assigned_user_id = $task['user_id'];

                        // Получаем имя пользователя, которому была назначена задача
                        $stmt = $pdo->prepare('SELECT full_name FROM users WHERE id = :user_id');
                        $stmt->execute(['user_id' => $assigned_user_id]);
                        $assigned_user = $stmt->fetch(PDO::FETCH_ASSOC)['full_name'];

                        $description = "Назначил задачу <strong>\"{$task['task_name']}\"</strong> с дедлайном <strong>{$task['task_deadline']}</strong> сотруднику <strong>{$assigned_user}</strong>";
                        break;
                    case 'report_added':
                        $activity_class = 'completed';
                        $description = "Создал отчет <strong>\"{$report_name}\"</strong> по задаче <strong>\"{$task['task_name']}\"</strong>, где указано: <strong>{$report_description}</strong>. Статус задачи изменился на выполненная.";
                        break;
                    case 'task_overdue':
                        $activity_class = 'overdue';
                        $description = "Не успел выполнить задачу <strong>\"{$task['task_name']}\"</strong> к сроку <strong>{$task['task_deadline']}</strong>. Статус задачи изменился на просроченная.";
                        break;
                    default:
                        $activity_class = '';
                        $description = "Неизвестная активность";
                        break;
                }
            ?>

                <div class="activity-item <?= $activity_class ?>">
                    <div>
                        <span class="activity-user"><?= $user_name ?></span>
                        <span class="activity-time"><?= date('d.m.Y, H:i', strtotime($activity['created_at'])) ?></span>
                    </div>
                    <p class="activity-description"><?= $description ?></p>
                </div>

            <?php } ?>
        </div>
    </div>

<?php include 'footer.inc'; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
