<?php
// Подключаем файл с настройками подключения к БД
include 'db.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Получаем данные из формы
    $last_name = trim($_POST['last_name']);
    $first_name = trim($_POST['first_name']);
    $middle_name = trim($_POST['middle_name']);

    // Убираем все символы, кроме кириллицы, из ФИО
    $last_name = preg_replace('/[^а-яА-ЯёЁ]/u', '', $last_name);
    $first_name = preg_replace('/[^а-яА-ЯёЁ]/u', '', $first_name);
    $middle_name = preg_replace('/[^а-яА-ЯёЁ]/u', '', $middle_name);

    // Объединяем ФИО в одну строку
    $full_name = $last_name . ' ' . $first_name . ' ' . $middle_name;

    // Убираем все нецифровые символы из номера телефона
    $phone = preg_replace('/\D/', '', $_POST['phone']);  // Убираем все нецифровые символы

    // Получаем email и пароль
    $email = $_POST['email'];
    $password = $_POST['password'];
    $role = $_POST['role'];

    // Хеширование пароля перед добавлением в базу данных
    $hashed_password = password_hash($password, PASSWORD_BCRYPT);

    // Подготовленный запрос для добавления пользователя в БД
    $stmt = $pdo->prepare('INSERT INTO users (full_name, email, password, phone, role) VALUES (:full_name, :email, :password, :phone, :role)');
    $stmt->execute([
        'full_name' => $full_name,
        'email' => $email,
        'password' => $hashed_password,
        'phone' => $phone,
        'role' => $role
    ]);

    echo "Пользователь успешно добавлен!";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Добавить пользователя</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<?php include 'header.inc' ?>
    <div class="container vh-100 d-flex justify-content-center align-items-center">
        <div class="card p-4 shadow-sm" style="width: 24rem;">
            <h3 class="text-center mb-4">Добавить пользователя</h3>
            <form method="POST">
                <div class="mb-3">
                    <label for="last_name" class="form-label">Фамилия</label>
                    <input type="text" class="form-control" id="last_name" name="last_name" placeholder="Введите фамилию" required maxlength="30" oninput="sanitizeName(this)">
                </div>
                <div class="mb-3">
                    <label for="first_name" class="form-label">Имя</label>
                    <input type="text" class="form-control" id="first_name" name="first_name" placeholder="Введите имя" required maxlength="30" oninput="sanitizeName(this)">
                </div>
                <div class="mb-3">
                    <label for="middle_name" class="form-label">Отчество</label>
                    <input type="text" class="form-control" id="middle_name" name="middle_name" placeholder="Введите отчество" required maxlength="30" oninput="sanitizeName(this)">
                </div>
                <div class="mb-3">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" class="form-control" id="email" name="email" placeholder="Введите email" required maxlength="30" oninput="sanitizeMail(this)">
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">Пароль</label>
                    <input type="password" class="form-control" id="password" name="password" placeholder="Введите пароль" required maxlength="30">
                </div>
                <div class="mb-3">
                    <label for="phone" class="form-label">Телефон</label>
                    <input type="text" class="form-control" id="phone" name="phone" placeholder="+7 (999) 999-99-99" required maxlength="18" onkeydown="maskPhone(event)">
                </div>
                <div class="mb-3">
                    <label for="role" class="form-label">Роль</label>
                    <select id="role" name="role" class="form-select">
                        <option value="user">Пользователь</option>
                        <option value="admin">Администратор</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary w-100">Добавить</button>
            </form>
        </div>
    </div>
<?php include 'footer.inc' ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        // Функция для маски ввода телефона в формате +7 (999) 999-99-99
        function maskPhone(event) {
            const input = event.target;
            let value = input.value.replace(/\D/g, '');  // Убираем все нецифровые символы

            if (value.length > 1) {
                value = '7' + value.slice(1); // Начинаем с 7
            }

            let formatted = '+7 '; // Добавляем префикс +7
            if (value.length > 1) formatted += '(' + value.substring(1, 4); // Код региона
            if (value.length > 4) formatted += ') ' + value.substring(4, 7); // Первая группа номеров
            if (value.length > 7) formatted += '-' + value.substring(7, 9); // Вторая группа номеров
            if (value.length > 9) formatted += '-' + value.substring(9, 11); // Третья группа номеров

            input.value = formatted;  // Применяем форматирование в поле ввода
        }

        // Функция для удаления символов, кроме кириллицы
        function sanitizeName(input) {
            input.value = input.value.replace(/[^а-яА-ЯёЁ\s]/g, ''); // Убираем все не кириллические символы
        }
        // Функция для удаления всего, кроме латиницы, цифр и символов
        function sanitizeMail(input) {
            input.value = input.value.replace(/[^a-zA-Z0-9\s@._-]/g, ''); // Разрешаем латиницу, цифры и символы @, ., _, -
        }
    </script>
</body>
</html>
