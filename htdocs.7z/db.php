<?php
$host = 'localhost'; // Адрес хоста
$dbname = 'project_management'; // Имя базы данных
$username = 'root'; // Имя пользователя для подключения к БД
$password = ''; // Пароль для подключения

try {
    // Подключение к базе данных с использованием PDO
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    // Устанавливаем режим обработки ошибок
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    // Устанавливаем кодировку
    $pdo->exec("SET NAMES utf8");
} catch (PDOException $e) {
    // В случае ошибки выводим сообщение
    echo 'Ошибка подключения: ' . $e->getMessage();
}
?>
