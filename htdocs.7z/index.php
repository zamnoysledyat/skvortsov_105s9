<?php
// Подключаем файл с настройками подключения к БД
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Получаем данные из формы
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Проверка данных
    if (empty($email) || empty($password)) {
        echo "Пожалуйста, заполните все поля.";
    } else {
        // Подготовленный запрос для проверки пользователя
        $stmt = $pdo->prepare('SELECT * FROM users WHERE email = :email');
        $stmt->execute(['email' => $email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        // Проверка пароля
        if ($user && password_verify($password, $user['password'])) {
            // Авторизация прошла успешно
            session_start();
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_role'] = $user['role'];
            header('Location: management_page.php'); // Переход на страницу после успешного входа
            exit();
        } else {
            echo "Неверный email или пароль.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Система управления проектами - Вход</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .info-block {
            background-color: #958FC4;
        }
        .info-block h2 {
            font-size: 2rem;
            font-weight: bold;
            color: #1D1D1D;
        }
        .info-block p {
            font-size: 1.2rem;
            line-height: 1.6;
            color: #1D1D1D;
        }
        .auth-block {
            background-color: #f0f2f5;
            padding-bottom: 30px;
        }
        .auth-card {
            background-color: #ffffff;
            border-radius: 30px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            max-width: 550px;
            width: 100%;
        }
        .auth-logo {
            width: 120px;
            border-radius: 50%;
            border: 4px solid #5D559B;
            padding: 8px;
        }
        .auth-card h2 {
            font-size: 1.8rem;
            font-weight: 600;
        }
        .auth-card .form-label {
            font-weight: 500;
        }
        .auth-card .form-control {
            border-radius: 8px;
            padding: 10px;
            font-size: 1rem;
        }
        .auth-card .btn-primary {
            background-color: #5D559B;
            border-color: #5D559B;
            border-radius: 8px;
            padding: 12px;
            font-size: 1.1rem;
            font-weight: 600;
        }
        .auth-card .btn-primary:hover {
            background-color: #4a4681;
            border-color: #4a4681;
        }
    </style>
    <script>
        // Функция для удаления всего, кроме латиницы, цифр и символов
        function sanitizeMail(input) {
            input.value = input.value.replace(/[^a-zA-Z0-9\s@._-]/g, ''); // Разрешаем латиницу, цифры и символы @, ., _, -
        }
    </script>
</head>
<body>

<?php include 'header.inc' ?>

    <!-- Информационный блок -->
    <section class="info-block py-3">
        <div class="container text-center">
            <h2 class="mb-2">Управляйте проектами легко — от идей до результата!</h2>
            <p class="mb-3">
                Оставайтесь организованными, улучшайте командное взаимодействие и достигайте целей быстрее с нашей системой управления проектами. 
                Простота, мощь и удобство — всё, что нужно для успеха вашего бизнеса.
            </p>
        </div>
    </section>
    
    <!-- Блок авторизации -->
    <section class="auth-block py-5">
        <div class="container d-flex justify-content-center align-items-center">
            <div class="auth-card p-4">
                <div class="text-center mb-4">
                    <img src="img/person.png" alt="Logo" class="auth-logo mb-3">
                    <h2 class="text-black">Добро пожаловать!</h2>
                </div>
                <form method="POST">
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="email" name="email" placeholder="Введите ваш email" required maxlength="30" oninput="sanitizeMail(this)">
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Пароль</label>
                        <input type="password" class="form-control" id="password" name="password" placeholder="Введите ваш пароль" required maxlength="30">
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Войти</button>
                </form>
            </div>
        </div>
    </section>

<?php include 'footer.inc' ?>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
