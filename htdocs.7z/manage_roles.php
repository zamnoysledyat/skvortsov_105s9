<?php
// Подключаем файл с настройками подключения к БД
include 'db.php';
session_start();

// Обработка изменения роли
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['user_id']) && isset($_POST['new_role'])) {
    $user_id = $_POST['user_id'];
    $new_role = $_POST['new_role'];
    
    try {
        $stmt = $pdo->prepare('UPDATE users SET role = :role WHERE id = :id');
        $stmt->execute([
            'role' => $new_role,
            'id' => $user_id
        ]);
        $success_message = "Роль пользователя успешно обновлена";
    } catch (PDOException $e) {
        $error_message = "Ошибка при обновлении роли";
    }
}

// Получаем список всех пользователей
$stmt = $pdo->query('SELECT id, full_name, email, role FROM users ORDER BY full_name');
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Управление ролями пользователей</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .role-select {
            max-width: 150px;
        }
        .user-table {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .table-header {
            background-color: #5D559B;
            color: white;
            border-radius: 10px 10px 0 0;
        }
        .success-message {
            animation: fadeOut 5s forwards;
        }
        @keyframes fadeOut {
            0% { opacity: 1; }
            70% { opacity: 1; }
            100% { opacity: 0; }
        }
    </style>
</head>
<body class="bg-light">

<?php include 'header.inc' ?>

<div class="container py-4">
    <h2 class="mb-4">Управление ролями пользователей</h2>
    
    <?php if (isset($success_message)): ?>
        <div class="alert alert-success success-message" role="alert">
            <?php echo $success_message; ?>
        </div>
    <?php endif; ?>

    <?php if (isset($error_message)): ?>
        <div class="alert alert-danger" role="alert">
            <?php echo $error_message; ?>
        </div>
    <?php endif; ?>

    <div class="user-table p-3">
        <table class="table table-hover mb-0">
            <thead class="table-header">
                <tr>
                    <th>ФИО</th>
                    <th>Email</th>
                    <th>Текущая роль</th>
                    <th>Изменить роль</th>
                    <th>Действия</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $user): ?>
                    <form method="POST" class="role-form">
                        <tr>
                            <td><?php echo htmlspecialchars($user['full_name']); ?></td>
                            <td><?php echo htmlspecialchars($user['email']); ?></td>
                            <td><?php echo $user['role'] === 'admin' ? 'Администратор' : 'Пользователь'; ?></td>
                            <td>
                                <select name="new_role" class="form-select role-select">
                                    <option value="user" <?php echo $user['role'] === 'user' ? 'selected' : ''; ?>>Пользователь</option>
                                    <option value="admin" <?php echo $user['role'] === 'admin' ? 'selected' : ''; ?>>Администратор</option>
                                </select>
                                <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                            </td>
                            <td>
                                <button type="submit" class="btn btn-primary btn-sm">Сохранить</button>
                            </td>
                        </tr>
                    </form>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
