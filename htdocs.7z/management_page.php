<?php
session_start();
include 'db.php';  // Подключение к базе данных

// Функция для обновления статуса задач, если они просрочены
function update_overdue_tasks($pdo) {
    $stmt = $pdo->query("SELECT id, task_deadline FROM tasks WHERE status = 'Активная'");
    $today = new DateTime();

    while ($task = $stmt->fetch()) {
        $task_deadline = new DateTime($task['task_deadline']);
        
        if ($task_deadline < $today) {
            $update_stmt = $pdo->prepare("UPDATE tasks SET status = 'Просроченная' WHERE id = ?");
            $update_stmt->execute([$task['id']]);
        }
    }
}

// Функция для добавления активности в таблицу `activity_feed`
function add_activity($pdo, $user_id, $activity_type, $task_id, $report_id, $description) {
    $query = "INSERT INTO activity_feed (user_id, activity_type, task_id, report_id, description, created_at) 
              VALUES (:user_id, :activity_type, :task_id, :report_id, :description, NOW())";
    
    $stmt = $pdo->prepare($query);
    
    // Привязываем параметры
    $stmt->bindParam(':user_id', $user_id);
    $stmt->bindParam(':activity_type', $activity_type);
    $stmt->bindParam(':task_id', $task_id);
    $stmt->bindParam(':report_id', $report_id);
    $stmt->bindParam(':description', $description);
    
    // Выполнение запроса
    $stmt->execute();
}

// Вызываем функцию для обновления статуса просроченных задач
update_overdue_tasks($pdo);

// Обработчик для добавления задачи
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_task'])) {
    $task_name = $_POST['task_name'];
    $task_deadline = $_POST['task_deadline'];

    // Вставка задачи в базу данных
    $stmt = $pdo->prepare("INSERT INTO tasks (task_name, task_deadline, status) VALUES (?, ?, 'Активная')");
    $stmt->execute([$task_name, $task_deadline]);
    $task_id = $pdo->lastInsertId();  // Получаем ID добавленной задачи

    // Добавление активности в таблицу `activity_feed`
    add_activity($pdo, $_SESSION['user_id'], 'task_created', $task_id, null, 'Задача была создана.');

    // Перенаправление после добавления
    header('Location: /management_page.php');
    exit();
}

// Обработчик для назначения задачи пользователю
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['assign_task'])) {
    $task_id = $_POST['task_id'];
    $user_id = $_POST['user_id'];

    // Обновление задачи с назначением пользователю и статусом "Активная"
    $stmt = $pdo->prepare("UPDATE tasks SET user_id = ?, status = 'Активная' WHERE id = ?");
    $stmt->execute([$user_id, $task_id]);

    // Добавление активности в таблицу `activity_feed`
    add_activity($pdo, $_SESSION['user_id'], 'task_assigned', $task_id, null, 'Задача была назначена.');

    // Перенаправление после назначения
    header('Location: /management_page.php');
    exit();
}

// Обработчик для добавления отчета
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_report'])) {
    $report_name = $_POST['report_name'];
    $report_desc = $_POST['report_desc'];
    $task_id = $_POST['task_id'];
    $user_id = $_SESSION['user_id']; // ID текущего пользователя

    try {
        // Начинаем транзакцию
        $pdo->beginTransaction();

        // Вставляем отчет в базу данных
        $stmt = $pdo->prepare("INSERT INTO reports (report_title, report_description, user_id, task_id, created_at) 
                               VALUES (?, ?, ?, ?, NOW())");
        $stmt->execute([$report_name, $report_desc, $user_id, $task_id]);
        $report_id = $pdo->lastInsertId();  // Получаем ID добавленного отчета

        // Обновляем статус задачи на "Выполненная"
        $update_task_stmt = $pdo->prepare("UPDATE tasks SET status = 'Выполненная' WHERE id = ?");
        $update_task_stmt->execute([$task_id]);

        // Добавление активности в таблицу `activity_feed`
        add_activity($pdo, $user_id, 'report_added', $task_id, $report_id, 'Отчёт был добавлен.');

        // Фиксируем транзакцию
        $pdo->commit();

        // Перенаправление после добавления
        header('Location: /management_page.php');
        exit();
    } catch (Exception $e) {
        // В случае ошибки откатываем транзакцию
        $pdo->rollBack();
        echo "Ошибка: " . $e->getMessage();
    }
}
?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Управление задачами и отчётами</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* Цвета для дедлайна */
        .task-red {
            background-color: #f8d7da;
        }

        .task-green {
            background-color: #d4edda;
        }

        .task-normal {
            background-color: transparent;
        }

        /* Прокрутка списка пользователей */
        .scrollable-users {
            max-height: 300px;
            overflow-y: auto;
        }

        /* Стиль для карточек */
        .card {
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .card:hover {
            transform: scale(1.05);
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.15);
        }

        /* Для скрытия/показа блока */
        .collapse {
            display: none;
        }

        .show {
            display: block;
        }

        /* Стили для кнопки раскрытия */
        .btn-toggle {
            background-color: #f8f9fa;
            border: 1px solid #ced4da;
            color: #007bff;
            font-weight: bold;
        }

        /* Дополнительные стили для карточек */
        .card-body {
            cursor: pointer;
        }
    </style>
</head>
<body>
<?php include 'header.inc' ?>

    <div class="container my-4">
        <h2>Управление задачами и отчётами</h2>
        <div class="row">
<!-- Форма добавления задачи или отчета -->
        <div class="col-md-6 mb-3">
            <?php if ($_SESSION['user_role'] == 'admin'): ?>
                <!-- Форма добавления задачи -->
                <form action="" method="POST" class="p-3 border rounded">
                    <h5>Добавить задачу</h5>
                    <div class="mb-3">
                        <label for="task-name" class="form-label">Название</label>
                        <input type="text" id="task-name" name="task_name" class="form-control" placeholder="Введите название задачи" required>
                    </div>
                    <div class="mb-3">
                        <label for="task-deadline" class="form-label">Дедлайн</label>
                        <input type="date" id="task-deadline" name="task_deadline" class="form-control" required>
                    </div>
                    <button type="submit" name="add_task" class="btn btn-success">Добавить</button>
                </form>
            <?php else: ?>
                <!-- Форма добавления отчета -->
                <form action="" method="POST" class="p-3 border rounded">
                    <h5>Добавить отчет</h5>
                    <div class="mb-3">
                        <label for="report-name" class="form-label">Название отчета</label>
                        <input type="text" id="report-name" name="report_name" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label for="report-desc" class="form-label">Описание</label>
                        <textarea id="report-desc" name="report_desc" class="form-control" rows="3" required></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="task-id" class="form-label">Выберите задачу</label>
                        <select id="task-id" name="task_id" class="form-select" required>
                            <?php
                            $stmt = $pdo->prepare("SELECT id, task_name FROM tasks WHERE user_id = ? AND status = 'Активная'");
                            $stmt->execute([$_SESSION['user_id']]);
                            while ($task = $stmt->fetch()) {
                                echo "<option value='{$task['id']}'>{$task['task_name']}</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <button type="submit" name="add_report" class="btn btn-success">Добавить</button>
                </form>
            <?php endif; ?>
        </div>

<!-- Список пользователей или задачи текущего пользователя -->
<div class="col-md-6">
    <h5>
        <?php
        if ($_SESSION['user_role'] == 'admin') {
            echo "Список пользователей";
        } else {
            echo "Ваши задачи";
        }
        ?>
    </h5>
    <div class="list-group scrollable-users">
    <?php
if ($_SESSION['user_role'] == 'admin') {
    // Получаем список пользователей (кроме администратора)
    $stmt = $pdo->query("SELECT id, full_name FROM users WHERE role != 'admin'");
    while ($user = $stmt->fetch()) {
        echo "<div class=\"list-group-item mb-4 p-4 border rounded shadow-sm\">";
        echo "<h5><strong>{$user['full_name']}</strong></h5>";

        // Получаем только активные задачи для пользователя
        $task_stmt = $pdo->prepare("SELECT id, task_name, task_deadline, status FROM tasks WHERE user_id = ? AND status = 'Активная'");
        $task_stmt->execute([$user['id']]);

        // Если есть активные задачи, отображаем их
        $tasks_assigned = $task_stmt->rowCount();
        if ($tasks_assigned > 0) {
            echo "<h6 class='mt-4 text-muted'>Задачи:</h6>";
            echo "<div class=\"list-group\">";
            while ($task = $task_stmt->fetch()) {
                // Вычисляем количество дней до дедлайна
                $task_deadline = new DateTime($task['task_deadline']);
                $today = new DateTime();
                $interval = $today->diff($task_deadline);
                $days_left = (int) $interval->format('%r%a');

                // Определяем класс для задачи в зависимости от дедлайна
                $task_class = 'task-normal'; // по умолчанию без цвета
                if ($days_left < 4) {
                    $task_class = 'task-red'; // Красный, если осталось меньше 4 дней
                } elseif ($days_left <= 10) {
                    $task_class = 'task-yellow'; // Желтый, если от 4 до 10 дней
                }

                // Дизайн задачи
                echo "<div class=\"list-group-item mb-2 p-3 border rounded $task_class\">";
                echo "<strong>{$task['task_name']}</strong><br>";
                echo "Дедлайн: {$task['task_deadline']}<br>";
                echo "Статус: <span class='badge badge-warning'>{$task['status']}</span>";
                echo "</div>";
            }
            echo "</div>";
        }

        // Отображаем свободные задачи, которые еще не назначены
        $free_tasks_stmt = $pdo->query("SELECT id, task_name, task_deadline FROM tasks WHERE user_id IS NULL AND status = 'Активная'");
        $free_tasks = $free_tasks_stmt->fetchAll();

        if (count($free_tasks) > 0) {
            echo "<h6 class='mt-4 text-muted'>Свободные задачи:</h6>";
            echo "<div class=\"list-group\">";
            foreach ($free_tasks as $task) {
                echo "<div class=\"list-group-item mb-2 p-3 border rounded\">";
                echo "<strong>{$task['task_name']}</strong><br>";
                echo "Дедлайн: {$task['task_deadline']}<br>";
                echo "<form method='POST' action='/management_page.php' class='d-inline'>";
                echo "<input type='hidden' name='task_id' value='{$task['id']}'>";
                echo "<input type='hidden' name='user_id' value='{$user['id']}'>";
                echo "<button type='submit' name='assign_task' class='btn btn-success btn-sm mt-2'>Назначить задачу</button>";
                echo "</form>";
                echo "</div>";
            }
            echo "</div>";
        }

        echo "</div>"; // Закрываем карточку пользователя
    }



        } else {
            // Получаем задачи текущего пользователя
            $user_id = $_SESSION['user_id'];
            $task_stmt = $pdo->prepare("SELECT id, task_name, task_deadline, status FROM tasks WHERE user_id = ? AND status = 'Активная'");
            $task_stmt->execute([$user_id]);

            // Если есть активные задачи, отображаем их
            if ($task_stmt->rowCount() > 0) {
                echo "<ul class=\"list-unstyled\">";
                while ($task = $task_stmt->fetch()) {
                    // Вычисляем количество дней до дедлайна
                    $task_deadline = new DateTime($task['task_deadline']);
                    $today = new DateTime();
                    $interval = $today->diff($task_deadline);
                    $days_left = (int) $interval->format('%r%a');

                    // Определяем класс для задачи в зависимости от дедлайна
                    $task_class = 'task-normal'; // по умолчанию без цвета
                    if ($days_left < 4) {
                        $task_class = 'task-red'; // Красный, если осталось меньше 4 дней
                    } elseif ($days_left <= 10) {
                        $task_class = 'task-green'; // Зеленый, если от 4 до 10 дней
                    }

                    echo "<li class=\"$task_class p-2 border rounded mb-2\">
                        {$task['task_name']} - Дедлайн: {$task['task_deadline']} - Статус: {$task['status']}
                    </li>";
                }
                echo "</ul>";
            } else {
                echo "<p>У вас нет активных задач.</p>";
            }
        }
        ?>
    </div>
</div>

        </div>
    </div>

<!-- Блоки для отчетов с анимацией -->
<div class="container my-4">
    <h2>Отчёты</h2>
    <div class="row">
        <?php
        // Получаем текущего пользователя
        $isAdmin = ($_SESSION['user_role'] == 'admin');
        $currentUserId = $_SESSION['user_id'];
        ?>

        <!-- Блок выполненных задач -->
        <div class="col-md-4">
            <div class="card text-center shadow">
                <div class="card-body" onclick="toggleTasks('completed')">
                    <h5 class="card-title">Задачи выполнены</h5>
                    <p class="display-4">
                        <?php
                        if ($isAdmin) {
                            $stmt = $pdo->query("SELECT COUNT(*) FROM tasks WHERE status = 'Выполненная'");
                        } else {
                            $stmt = $pdo->prepare("SELECT COUNT(*) FROM tasks WHERE status = 'Выполненная' AND user_id = ?");
                            $stmt->execute([$currentUserId]);
                        }
                        echo $stmt->fetchColumn();
                        ?>
                    </p>
                </div>
                <div id="completed-tasks" class="collapse">
                    <hr>
                    <ul class="list-group list-group-flush">
                        <?php
                        if ($isAdmin) {
                            $stmt = $pdo->query("SELECT t.id, t.task_name, t.task_deadline, u.full_name FROM tasks t
                                                 LEFT JOIN users u ON t.user_id = u.id
                                                 WHERE t.status = 'Выполненная'");
                        } else {
                            $stmt = $pdo->prepare("SELECT t.id, t.task_name, t.task_deadline FROM tasks t
                                                   WHERE t.status = 'Выполненная' AND t.user_id = ?");
                            $stmt->execute([$currentUserId]);
                        }
                        while ($task = $stmt->fetch()) {
                            echo "<li class='list-group-item bg-warning text-decoration-line-through'>";
                            echo "<strong>{$task['task_name']}</strong><br>";
                            if ($isAdmin) echo "Пользователь: {$task['full_name']}<br>";
                            echo "Дедлайн: {$task['task_deadline']}";
                            echo "</li>";
                        }
                        ?>
                    </ul>
                </div>
            </div>
        </div>

        <!-- Блок просроченных задач -->
        <div class="col-md-4">
            <div class="card text-center shadow">
                <div class="card-body" onclick="toggleTasks('overdue')">
                    <h5 class="card-title">Просроченные задачи</h5>
                    <p class="display-4">
                        <?php
                        if ($isAdmin) {
                            $stmt = $pdo->query("SELECT COUNT(*) FROM tasks WHERE status = 'Просроченная'");
                        } else {
                            $stmt = $pdo->prepare("SELECT COUNT(*) FROM tasks WHERE status = 'Просроченная' AND user_id = ?");
                            $stmt->execute([$currentUserId]);
                        }
                        echo $stmt->fetchColumn();
                        ?>
                    </p>
                </div>
                <div id="overdue-tasks" class="collapse">
                    <hr>
                    <ul class="list-group list-group-flush">
                        <?php
                        if ($isAdmin) {
                            $stmt = $pdo->query("SELECT t.id, t.task_name, t.task_deadline, u.full_name FROM tasks t
                                                 LEFT JOIN users u ON t.user_id = u.id
                                                 WHERE t.status = 'Просроченная'");
                        } else {
                            $stmt = $pdo->prepare("SELECT t.id, t.task_name, t.task_deadline FROM tasks t
                                                   WHERE t.status = 'Просроченная' AND t.user_id = ?");
                            $stmt->execute([$currentUserId]);
                        }
                        while ($task = $stmt->fetch()) {
                            echo "<li class='list-group-item bg-secondary text-light'>";
                            echo "<strong>{$task['task_name']}</strong><br>";
                            if ($isAdmin) echo "Пользователь: {$task['full_name']}<br>";
                            echo "Дедлайн: {$task['task_deadline']}";
                            echo "</li>";
                        }
                        ?>
                    </ul>
                </div>
            </div>
        </div>

        <!-- Блок активных задач -->
        <div class="col-md-4">
            <div class="card text-center shadow">
                <div class="card-body" onclick="toggleTasks('active')">
                    <h5 class="card-title">Активные задачи</h5>
                    <p class="display-4">
                        <?php
                        if ($isAdmin) {
                            $stmt = $pdo->query("SELECT COUNT(*) FROM tasks WHERE status = 'Активная'");
                        } else {
                            $stmt = $pdo->prepare("SELECT COUNT(*) FROM tasks WHERE status = 'Активная' AND user_id = ?");
                            $stmt->execute([$currentUserId]);
                        }
                        echo $stmt->fetchColumn();
                        ?>
                    </p>
                </div>
                <div id="active-tasks" class="collapse">
                    <hr>
                    <ul class="list-group list-group-flush">
                        <?php
                        if ($isAdmin) {
                            $stmt = $pdo->query("SELECT t.id, t.task_name, t.task_deadline, u.full_name FROM tasks t
                                                 LEFT JOIN users u ON t.user_id = u.id
                                                 WHERE t.status = 'Активная'");
                        } else {
                            $stmt = $pdo->prepare("SELECT t.id, t.task_name, t.task_deadline FROM tasks t
                                                   WHERE t.status = 'Активная' AND t.user_id = ?");
                            $stmt->execute([$currentUserId]);
                        }
                        while ($task = $stmt->fetch()) {
                            $task_deadline = new DateTime($task['task_deadline']);
                            $today = new DateTime();
                            $days_left = (int) $today->diff($task_deadline)->format('%r%a');
                            $colorClass = ($days_left <= 4) ? 'bg-danger text-light' : 'bg-success text-light';

                            echo "<li class='list-group-item {$colorClass}'>";
                            echo "<strong>{$task['task_name']}</strong><br>";
                            if ($isAdmin) echo "Пользователь: {$task['full_name']}<br>";
                            echo "Дедлайн: {$task['task_deadline']}<br>";
                            echo "Осталось дней: {$days_left}";
                            echo "</li>";
                        }
                        ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>



<?php include 'footer.inc' ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Функция для раскрытия блоков
        function toggleTasks(status) {
            let taskList = document.getElementById(status + '-tasks');
            if (taskList.classList.contains('collapse')) {
                taskList.classList.remove('collapse');
                taskList.classList.add('show');
            } else {
                taskList.classList.remove('show');
                taskList.classList.add('collapse');
            }
        }
    </script>
</body>
</html>
