<?php
// Подключаем файл с настройками подключения к БД
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Получаем данные из формы
    $last_name = trim($_POST['last_name']);
    $first_name = trim($_POST['first_name']);
    $middle_name = trim($_POST['middle_name']);
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $phone = $_POST['phone'];

    // Убираем все символы, кроме кириллицы, из ФИО
    $last_name = preg_replace('/[^а-яА-ЯёЁ]/u', '', $last_name);
    $first_name = preg_replace('/[^а-яА-ЯёЁ]/u', '', $first_name);
    $middle_name = preg_replace('/[^а-яА-ЯёЁ]/u', '', $middle_name);

    // Объединяем ФИО в одну строку
    $full_name = $last_name . ' ' . $first_name . ' ' . $middle_name;
    
    // Убираем все нецифровые символы из номера телефона
    $phone = preg_replace('/\D/', '', $phone);

    // Проверка данных
    if (empty($email) || empty($password) || empty($confirm_password) || 
        empty($last_name) || empty($first_name) || empty($middle_name) || empty($phone)) {
        $error = "Пожалуйста, заполните все поля.";
    } elseif ($password !== $confirm_password) {
        $error = "Пароли не совпадают.";
    } else {
        // Проверяем, не существует ли уже такой email
        $stmt = $pdo->prepare('SELECT COUNT(*) FROM users WHERE email = :email');
        $stmt->execute(['email' => $email]);
        $count = $stmt->fetchColumn();

        if ($count > 0) {
            $error = "Пользователь с таким email уже существует.";
        } else {
            // Хешируем пароль
            $hashed_password = password_hash($password, PASSWORD_BCRYPT);
            
            // Подготовленный запрос для добавления пользователя
            try {
                $stmt = $pdo->prepare('INSERT INTO users (full_name, email, password, phone, role, created_at) VALUES (:full_name, :email, :password, :phone, :role, :created_at)');
                $stmt->execute([
                    'full_name' => $full_name,
                    'email' => $email,
                    'password' => $hashed_password,
                    'phone' => $phone,
                    'role' => 'user',
                    'created_at' => date('Y-m-d H:i:s')
                ]);
                
                // Перенаправляем на страницу входа
                header('Location: index.php?registered=1');
                exit();
            } catch (PDOException $e) {
                $error = "Ошибка при регистрации. Пожалуйста, попробуйте позже.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Система управления проектами - Регистрация</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .info-block {
            background-color: #958FC4;
        }
        .info-block h2 {
            font-size: 2rem;
            font-weight: bold;
            color: #1D1D1D;
        }
        .info-block p {
            font-size: 1.2rem;
            line-height: 1.6;
            color: #1D1D1D;
        }
        .auth-block {
            background-color: #f0f2f5;
            padding: 40px 0;
        }
        .auth-card {
            background-color: #ffffff;
            border-radius: 30px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            max-width: 550px;
            width: 100%;
            padding: 40px;
            margin: 0 auto;
        }
        .auth-logo {
            width: 120px;
            margin-bottom: 20px;
        }
        .auth-card h2 {
            font-size: 1.8rem;
            font-weight: 600;
            margin-bottom: 30px;
            color: #333;
        }
        .form-label {
            font-weight: 500;
            margin-bottom: 8px;
            color: #333;
        }
        .form-control {
            border-radius: 8px;
            padding: 12px;
            font-size: 1rem;
            border: 1px solid #ddd;
            margin-bottom: 20px;
        }
        .form-control:focus {
            border-color: #5D559B;
            box-shadow: 0 0 0 0.2rem rgba(93, 85, 155, 0.25);
        }
        .btn-primary {
            background-color: #5D559B;
            border-color: #5D559B;
            border-radius: 8px;
            padding: 12px;
            font-size: 1.1rem;
            font-weight: 600;
            width: 100%;
            margin-top: 20px;
        }
        .btn-primary:hover {
            background-color: #4a4681;
            border-color: #4a4681;
        }
        .login-link {
            margin-top: 20px;
            text-align: center;
        }
        .login-link a {
            color: #5D559B;
            text-decoration: none;
        }
        .login-link a:hover {
            text-decoration: underline;
        }
    </style>
    <script>
        // Функция для маски ввода телефона в формате +7 (999) 999-99-99
        function maskPhone(event) {
            const input = event.target;
            let value = input.value.replace(/\D/g, '');  // Убираем все нецифровые символы

            if (value.length > 1) {
                value = '7' + value.slice(1); // Начинаем с 7
            }

            let formatted = '+7 '; // Добавляем префикс +7
            if (value.length > 1) formatted += '(' + value.substring(1, 4); // Код региона
            if (value.length > 4) formatted += ') ' + value.substring(4, 7); // Первая группа номеров
            if (value.length > 7) formatted += '-' + value.substring(7, 9); // Вторая группа номеров
            if (value.length > 9) formatted += '-' + value.substring(9, 11); // Третья группа номеров

            input.value = formatted;  // Применяем форматирование в поле ввода
        }

        // Функция для удаления символов, кроме кириллицы
        function sanitizeName(input) {
            input.value = input.value.replace(/[^а-яА-ЯёЁ\s]/g, ''); // Убираем все не кириллические символы
        }
        
        // Функция для удаления всего, кроме латиницы, цифр и символов
        function sanitizeMail(input) {
            input.value = input.value.replace(/[^a-zA-Z0-9\s@._-]/g, ''); // Разрешаем латиницу, цифры и символы @, ., _, -
        }
    </script>
</head>
<body>

<?php include 'header.inc' ?>

    <!-- Информационный блок -->
    <section class="info-block py-3">
        <div class="container text-center">
            <h2 class="mb-2">Присоединяйтесь к нашей системе управления проектами!</h2>
            <p class="mb-3">
                Создайте аккаунт прямо сейчас и получите доступ ко всем возможностям системы.
                Эффективное управление задачами, совместная работа и контроль проектов в одном месте.
            </p>
        </div>
    </section>

    <!-- Блок регистрации -->
    <section class="auth-block">
        <div class="container">
            <div class="auth-card">
                <div class="text-center">
                    <img src="img/person.png" alt="User Icon" class="auth-logo">
                    <h2>Регистрация</h2>
                    <?php if (isset($error)): ?>
                        <div class="alert alert-danger"><?php echo $error; ?></div>
                    <?php endif; ?>
                </div>
                <form method="POST" action="register.php">
                    <div class="mb-3">
                        <label for="last_name" class="form-label">Фамилия</label>
                        <input type="text" class="form-control" id="last_name" name="last_name" 
                               placeholder="Введите фамилию" required maxlength="30" 
                               oninput="sanitizeName(this)">
                    </div>
                    <div class="mb-3">
                        <label for="first_name" class="form-label">Имя</label>
                        <input type="text" class="form-control" id="first_name" name="first_name" 
                               placeholder="Введите имя" required maxlength="30" 
                               oninput="sanitizeName(this)">
                    </div>
                    <div class="mb-3">
                        <label for="middle_name" class="form-label">Отчество</label>
                        <input type="text" class="form-control" id="middle_name" name="middle_name" 
                               placeholder="Введите отчество" required maxlength="30" 
                               oninput="sanitizeName(this)">
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="email" name="email" 
                               placeholder="Введите email" required maxlength="30"
                               oninput="sanitizeMail(this)">
                    </div>
                    <div class="mb-3">
                        <label for="phone" class="form-label">Телефон</label>
                        <input type="text" class="form-control" id="phone" name="phone" 
                               placeholder="+7 (999) 999-99-99" required maxlength="18" 
                               onkeydown="maskPhone(event)">
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Пароль</label>
                        <input type="password" class="form-control" id="password" name="password" 
                               placeholder="Введите пароль" required maxlength="30">
                    </div>
                    <div class="mb-3">
                        <label for="confirm_password" class="form-label">Подтвердите пароль</label>
                        <input type="password" class="form-control" id="confirm_password" name="confirm_password" 
                               placeholder="Повторите пароль" required maxlength="30">
                    </div>
                    <button type="submit" class="btn btn-primary">Зарегистрироваться</button>
                    <div class="login-link">
                        <p>Уже есть аккаунт? <a href="index.php">Войти</a></p>
                    </div>
                </form>
            </div>
        </div>
    </section>

<?php include 'footer.inc' ?>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
