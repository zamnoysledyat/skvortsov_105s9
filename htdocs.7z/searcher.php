<?php
session_start();
// Подключение к базе данных
include 'db.php';

// Проверяем, был ли выполнен поиск
$search_results_tasks = [];
$search_results_reports = [];
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['search_query'])) {
    $search_query = $_GET['search_query'];

    if (!empty($search_query)) {
        $like_query = "%$search_query%";

        // Поиск по задачам
        $query_tasks = $pdo->prepare("
            SELECT 
                tasks.id AS task_id, 
                tasks.task_name, 
                tasks.task_deadline, 
                users.full_name AS assigned_user, 
                tasks.status, 
                tasks.created_at 
            FROM tasks
            LEFT JOIN users ON tasks.user_id = users.id
            WHERE tasks.task_name LIKE :query OR tasks.status LIKE :query
        ");
        $query_tasks->execute(['query' => $like_query]);
        $search_results_tasks = $query_tasks->fetchAll(PDO::FETCH_ASSOC);

        // Поиск по отчётам
        $query_reports = $pdo->prepare("
            SELECT 
                reports.id AS report_id, 
                reports.report_title, 
                reports.report_description, 
                users.full_name AS author_name, 
                tasks.task_name AS related_task, 
                reports.created_at 
            FROM reports
            LEFT JOIN users ON reports.user_id = users.id
            LEFT JOIN tasks ON reports.task_id = tasks.id
            WHERE reports.report_title LIKE :query OR reports.report_description LIKE :query
        ");
        $query_reports->execute(['query' => $like_query]);
        $search_results_reports = $query_reports->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Поиск</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<?php include 'header.inc'; ?>

<div class="container my-5">
    <h1 class="text-center mb-4">Поиск</h1>
    <form method="GET" action="" class="d-flex justify-content-center mb-5">
        <input type="text" name="search_query" class="form-control me-2" style="max-width: 400px;" placeholder="Введите запрос" value="<?php echo htmlspecialchars($_GET['search_query'] ?? ''); ?>" required>
        <button type="submit" class="btn btn-primary">Искать</button>
    </form>

    <?php if (!empty($search_results_tasks) || !empty($search_results_reports)): ?>
        <div class="search-results">
            <!-- Результаты задач -->
            <?php if (!empty($search_results_tasks)): ?>
                <div class="card mb-4">
                    <div class="card-header bg-primary text-white">
                        <h2 class="h5 mb-0">Результаты поиска по задачам</h2>
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Название</th>
                                    <th>Исполнитель</th>
                                    <th>Срок</th>
                                    <th>Статус</th>
                                    <th>Создано</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($search_results_tasks as $task): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($task['task_name']); ?></td>
                                        <td><?php echo htmlspecialchars($task['assigned_user'] ?? 'Не назначено'); ?></td>
                                        <td><?php echo htmlspecialchars($task['task_deadline']); ?></td>
                                        <td><?php echo htmlspecialchars($task['status']); ?></td>
                                        <td><?php echo htmlspecialchars($task['created_at']); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Результаты отчётов -->
            <?php if (!empty($search_results_reports)): ?>
                <div class="card">
                    <div class="card-header bg-success text-white">
                        <h2 class="h5 mb-0">Результаты поиска по отчётам</h2>
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Заголовок</th>
                                    <th>Описание</th>
                                    <th>Автор</th>
                                    <th>Связанная задача</th>
                                    <th>Дата создания</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($search_results_reports as $report): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($report['report_title']); ?></td>
                                        <td><?php echo htmlspecialchars($report['report_description']); ?></td>
                                        <td><?php echo htmlspecialchars($report['author_name'] ?? 'Неизвестно'); ?></td>
                                        <td><?php echo htmlspecialchars($report['related_task'] ?? 'Не указано'); ?></td>
                                        <td><?php echo htmlspecialchars($report['created_at']); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    <?php elseif ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['search_query'])): ?>
        <div class="alert alert-warning text-center">Ничего не найдено.</div>
    <?php endif; ?>
</div>

<?php include 'footer.inc'; ?>
<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
