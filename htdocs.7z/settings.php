<?php
// Подключаем файл с настройками подключения к БД
include 'db.php';
session_start();

// Проверяем, если пользователь не авторизован, перенаправляем на страницу входа
if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit();
}

// Получаем текущие данные пользователя из БД
$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare('SELECT * FROM users WHERE id = :user_id');
$stmt->execute(['user_id' => $user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// Обработка формы для обновления данных пользователя
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $phone = preg_replace('/\D/', '', $_POST['phone']); // Убираем все нецифровые символы

    // Если пароль не пустой, хешируем его
    if (!empty($password)) {
        $hashed_password = password_hash($password, PASSWORD_BCRYPT);
    } else {
        // Если пароль не изменен, сохраняем старый
        $hashed_password = $user['password'];
    }

    // Обновляем данные пользователя в базе данных
    $stmt = $pdo->prepare('UPDATE users SET email = :email, password = :password, phone = :phone WHERE id = :user_id');
    $stmt->execute([
        'email' => $email,
        'password' => $hashed_password,
        'phone' => $phone,
        'user_id' => $user_id
    ]);

    echo "Данные успешно обновлены!";
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Настройки пользователя</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .auth-card {
            background-color: #ffffff;
            border-radius: 30px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            max-width: 550px;
            width: 100%;
        }
        .auth-card h2 {
            font-size: 1.8rem;
            font-weight: 600;
        }
        .auth-card .form-label {
            font-weight: 500;
        }
        .auth-card .form-control {
            border-radius: 8px;
            padding: 10px;
            font-size: 1rem;
        }
        .auth-card .btn-primary {
            background-color: #5D559B;
            border-color: #5D559B;
            border-radius: 8px;
            padding: 12px;
            font-size: 1.1rem;
            font-weight: 600;
        }
        .auth-card .btn-primary:hover {
            background-color: #4a4681;
            border-color: #4a4681;
        }
    </style>
    <script>
        // Функция для маски ввода телефона в формате +7 (999) 999-99-99
        function maskPhone(event) {
            const input = event.target;
            let value = input.value.replace(/\D/g, '');  // Убираем все нецифровые символы

            if (value.length > 1) {
                value = '7' + value.slice(1); // Начинаем с 7
            }

            let formatted = '+7 '; // Добавляем префикс +7
            if (value.length > 1) formatted += '(' + value.substring(1, 4); // Код региона
            if (value.length > 4) formatted += ') ' + value.substring(4, 7); // Первая группа номеров
            if (value.length > 7) formatted += '-' + value.substring(7, 9); // Вторая группа номеров
            if (value.length > 9) formatted += '-' + value.substring(9, 11); // Третья группа номеров

            input.value = formatted;  // Применяем форматирование в поле ввода
        }

        // Функция для удаления всего, кроме латиницы, цифр и символов
        function sanitizeMail(input) {
            input.value = input.value.replace(/[^a-zA-Z0-9\s@._-]/g, ''); // Разрешаем латиницу, цифры и символы @, ., _, -
        }
    </script>
</head>
<body>
    <?php include 'header.inc' ?>

    <section class="container py-5">
        <div class="d-flex justify-content-center align-items-center">
            <div class="auth-card p-4">
                <h2 class="text-center mb-4">Настройки пользователя</h2>
                <form method="POST">
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" placeholder="Введите ваш email" required oninput="sanitizeMail(this)">
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Пароль</label>
                        <input type="password" class="form-control" id="password" name="password" placeholder="Введите новый пароль (если хотите изменить)">
                    </div>
                    <div class="mb-3">
                        <label for="phone" class="form-label">Телефон</label>
                        <input type="text" class="form-control" id="phone" name="phone" value="<?= htmlspecialchars($user['phone']) ?>" placeholder="Введите ваш телефон" required oninput="maskPhone(event)">
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Сохранить изменения</button>
                </form>
            </div>
        </div>
    </section>

    <?php include 'footer.inc' ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
